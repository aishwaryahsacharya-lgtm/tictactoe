const cells = document.querySelectorAll(".cell");
const turnText = document.getElementById("turn");
const restartBtn = document.getElementById("restartBtn");
const resetScoresBtn = document.getElementById("resetScoresBtn");
const overlay = document.getElementById("overlay");
const winnerText = document.getElementById("winnerText");
const newGameBtn = document.getElementById("newGameBtn");

let currentPlayer = "X";
let scores = { X: 0, O: 0, draws: 0 };
let board = ["", "", "", "", "", "", "", "", ""];
let gameOver = false;

// Update scores
function updateScores() {
  document.getElementById("scoreX").textContent = scores.X;
  document.getElementById("scoreO").textContent = scores.O;
  document.getElementById("scoreDraws").textContent = scores.draws;
}

// Winning patterns
const winPatterns = [
  [0, 1, 2],
  [3, 4, 5],
  [6, 7, 8],
  [0, 3, 6],
  [1, 4, 7],
  [2, 5, 8],
  [0, 4, 8],
  [2, 4, 6],
];

// Check winner
function checkWinner() {
  for (let pattern of winPatterns) {
    const [a, b, c] = pattern;
    if (board[a] && board[a] === board[b] && board[a] === board[c]) {
      gameOver = true;
      scores[board[a]]++;
      updateScores();
      showOverlay(`Player ${board[a]} wins!`);
      return;
    }
  }

  if (!board.includes("") && !gameOver) {
    gameOver = true;
    scores.draws++;
    updateScores();
    showOverlay("It's a Draw!");
  }
}

// Handle click on each cell
cells.forEach((cell, index) => {
  cell.addEventListener("click", () => {
    if (board[index] === "" && !gameOver) {
      board[index] = currentPlayer;
      cell.textContent = currentPlayer;
      cell.classList.add("disabled");

      checkWinner();

      if (!gameOver) {
        currentPlayer = currentPlayer === "X" ? "O" : "X";
        turnText.textContent = "Turn: " + currentPlayer;
      }
    }
  });
});

// Show overlay
function showOverlay(message) {
  winnerText.textContent = message;
  overlay.style.display = "flex";
}

// Reset the board
function resetBoard() {
  board = ["", "", "", "", "", "", "", "", ""];
  cells.forEach(cell => {
    cell.textContent = "";
    cell.classList.remove("disabled");
  });
  currentPlayer = "X";
  gameOver = false;
  turnText.textContent = "Turn: " + currentPlayer;
  overlay.style.display = "none"; // hide overlay
}

// Restart button
restartBtn.addEventListener("click", resetBoard);

// Reset scores button
resetScoresBtn.addEventListener("click", () => {
  scores = { X: 0, O: 0, draws: 0 };
  updateScores();
  resetBoard();
});

// New Game button in overlay
newGameBtn.addEventListener("click", resetBoard);

// Initialize
updateScores();
